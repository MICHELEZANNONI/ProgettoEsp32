public class FilerException extends Exception {

}































/*  private String matter="";
    public FilerException(String matter) {
        this.matter = matter;
    }
    public String getMatter() {
        return this.matter;
    } */













