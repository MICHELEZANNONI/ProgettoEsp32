import javax.annotation.processing.FilerException;
import java.io.IOException;
import java.util.Scanner;

public class TestStatistica {
    public static void main(String args[]) throws IOException {
        int scelta;
        Statistica statistica = new Statistica();
        TextFile out = new TextFile("misurazioni.txt", 'W');
        Scanner s = new Scanner(System.in);

        do {
            scelta = TestStatistica.menu();
            switch (scelta) {
                case 0:
                    break;
                case 1:
                    int temperatura = readTemperatura();
                    System.out.println("Inserisci aula: ");
                    String aula = s.nextLine();
                    System.out.println("Inserisci data: ");
                    String data = s.nextLine();
                    int ora = readOra();
                    int minuti = readMinuti();
                    int id = 0;
                    Misurazione misurazione = new Misurazione(temperatura, aula, data, ora, minuti, id);
                    statistica.aggiungiMisurazione(misurazione);
                    id++;
                    break;
                case 2:
                    statistica.salvaMisurazioni();
                    break;
                case 3:
                    statistica.caricaMisurazioni();
                    break;
            }
        } while (scelta != 0);
    }

    private static int readTemperatura() {
        Scanner s = new Scanner(System.in);
        boolean ok = false;
        int temperatura = 0;
        do {
            try {
                System.out.println("Inserisci temperatura: ");
                String temperaturaString = s.nextLine();
                temperatura = Integer.parseInt(temperaturaString);
                ok = true;
            } catch (NumberFormatException exception) {
                System.out.println("Inserimento sbagliato!");
            }
        } while (!ok);
        return temperatura;
    }

    private static int readOra() {
        Scanner s = new Scanner(System.in);
        boolean ok = false;
        int ora = 0;
        do {
            try {
                System.out.println("Inserisci ora: ");
                String oraString = s.nextLine();
                ora = Integer.parseInt(oraString);
                ok = true;
            } catch (NumberFormatException exception) {
                System.out.println("Inserimento sbagliato!");
            }
        } while (!ok);
        return ora;
    }

    private static int readMinuti() {
        Scanner s = new Scanner(System.in);
        boolean ok = false;
        int minuti = 0;
        do {
            try {
                System.out.println("Inserisci minuti: ");
                String minutiString = s.nextLine();
                minuti = Integer.parseInt(minutiString);
                ok = true;
            } catch (NumberFormatException exception) {
                System.out.println("Inserimento sbagliato!");
            }
        } while (!ok);
        return minuti;
    }

    static public int menu() {
        int scelta = 0;
        System.out.println("Menu");
        System.out.println("1) Aggiungi misurazione");
        System.out.println("2) Salva su file");
        System.out.println("3) Leggi da file");
        System.out.println("0) Esci");
        System.out.println("Scegli : ");
        Scanner s = new Scanner(System.in);
        try {
            scelta = s.nextInt();
        } catch (java.util.InputMismatchException e) {
            System.out.println("scelta errata");
        }
        return scelta;
    }
}
