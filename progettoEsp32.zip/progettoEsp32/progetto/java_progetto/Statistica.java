import java.util.Arrays;

import javax.annotation.processing.FilerException;

public class Statistica {

    private final int MAX_MISURAZIONI = 1;
    Misurazione[] misurazioni = new Misurazione[MAX_MISURAZIONI];

    public Misurazione aggiungiMisurazione(Misurazione misurazione) {
        int i = primaPosLibera();
        if (i >= 0) {
            misurazioni[i] = misurazione;
            return misurazione;
        }
        return null;
    }

    private int primaPosLibera() {
        int i;
        for (i = 0; i < MAX_MISURAZIONI; i++) {
            if (misurazioni[i] == null) {
                return i;
            }
        }
        return -1;
    }

    public void salvaMisurazioni() throws java.io.IOException {
        TextFile out = new TextFile("misurazioni.txt", 'W');
        try {
            for (int posizione = 0; posizione < MAX_MISURAZIONI; posizione++) {
                if (misurazioni[posizione] != null) {
                    String line = Integer.toString(posizione);
                    line += ";" + misurazioni[posizione].getTemperatura();
                    line += ";" + misurazioni[posizione].getAula();
                    line += ";" + misurazioni[posizione].getData();
                    line += ";" + misurazioni[posizione].getOra();
                    line += ";" + misurazioni[posizione].getMinuti();
                    out.toFile(line);
                }
            }
        } catch (FilerException exception) {
        }
        out.closeFile();
    }

    public void caricaMisurazioni() throws java.io.IOException {
        TextFile in = new TextFile("misurazioni.txt", 'R');
        int posizione, ora, minuti, temperatura;
        String Aula, Data;
        String[] elementi;
        Misurazione misurazione;
        try {
            while (true) {
                String linea = in.fromFile();
                elementi = linea.split(";");
                if (elementi.length == 4) {
                    posizione = Integer.parseInt(elementi[0]);
                    temperatura = Integer.parseInt(elementi[1]);
                    Aula = elementi[2];
                    Data = elementi[3];
                    ora = Integer.parseInt(elementi[4]);
                    minuti = Integer.parseInt(elementi[5]);
                    misurazione = new Misurazione(temperatura, Aula, Data, ora, minuti);
                }
            }
            System.out.println(misurazione);
        } catch (FilerException exception) {
        }
        
    }

    
}
