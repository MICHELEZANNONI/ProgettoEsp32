public class Misurazione {
    private int temperatura;
    private String aula;
    private String data;
    private int ora;
    private int minuti;
    private int id;

    public Misurazione(int temperatura, String aula, String data, int ora, int minuti, int id) {
        this.temperatura = temperatura;
        this.aula = aula;
        this.data = data;
        this.ora = ora;
    }

    public String toString(){
        String s;
        s = "Temperatura " + temperatura + " aula " + aula + " data " + data + ";" + ora + ":" + minuti;
        return s;
    }

    public int getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(int temperatura) {
        this.temperatura = temperatura;
    }

    public String getAula() {
        return aula;
    }

    public void setAula(String aula) {
        this.aula = aula;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getOra() {
        return ora;
    }

    public void setOra(int ora) {
        this.ora = ora;
    }

    public int getMinuti() {
        return minuti;
    }

    public void setMinuti(int minuti) {
        this.minuti = minuti;
    }
       
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}